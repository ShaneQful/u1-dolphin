u1-dolphin
==========

Ubuntu One KDE Dolphin Plugin

To install

sudo apt-get install ruby

sudo apt-get install ubuntuone-control-panel-qt

then place all the files in

"home/yourusername/.kde/share/kde4/services/ServiceMenus/"

for more visit info or to get in touch visit http://www.softwareontheside.info/
